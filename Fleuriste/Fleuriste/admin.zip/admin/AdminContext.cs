﻿using BDD.Main;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDD.Admin
{
    public class AdminContext : Context
    {
        public OwnerItem ItemPage { get; private set; }
        public OwnerStore StorePage { get; private set; }
        public OwnerUser UserPage { get; private set; }

        public AdminContext(MainWindow main) : base(main)
        {
            ItemPage = new(this);
            StorePage = new(this);
            UserPage = new(this);

            AddMenuButton("Items", ItemPage);
            AddMenuButton("Stores", StorePage);
            AddMenuButton("Users", UserPage);
            AddMenuButton("Logout", Logout);
            SetContent(ItemPage);
        }

        private void Logout() => MainWindow.Context = new MainContext(MainWindow);
    }
}
